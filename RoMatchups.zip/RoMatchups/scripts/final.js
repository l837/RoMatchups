"use strict"

areAllContentScriptsLoaded = true

if(isInitDeferred) {
	Init()
}