"use strict"

pageInit.avatar = () => {}