"use strict"

pageInit.home = function() {
}